-- Migración 2: campos adicionales de pipeline, avisos, y permisos de nombre
-- Pega y corre esto completo en Supabase → SQL Editor

alter table prospectos add column if not exists telefono text;
alter table prospectos add column if not exists comentarios text;
alter table prospectos add column if not exists fecha_cierre_tentativa date;
alter table prospectos add column if not exists monto numeric;

create table if not exists avisos (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references auth.users(id) on delete cascade,
  mensaje text not null,
  created_at timestamptz not null default now()
);

alter table avisos enable row level security;

drop policy if exists "todos ven avisos" on avisos;
create policy "todos ven avisos" on avisos
  for select using (auth.uid() is not null);

drop policy if exists "solo admin publica avisos" on avisos;
create policy "solo admin publica avisos" on avisos
  for insert with check (is_admin());

drop policy if exists "solo admin borra avisos" on avisos;
create policy "solo admin borra avisos" on avisos
  for delete using (is_admin());

grant select, insert, delete on avisos to authenticated;

-- Permitir que el admin actualice el nombre y rol de cualquier perfil
drop policy if exists "usuario actualiza su propio perfil" on perfiles;
create policy "usuario o admin actualiza perfil" on perfiles
  for update using (id = auth.uid() or is_admin());
